def init():
    import main.routes.signup
    import main.routes.login
    import main.routes.notes
    import main.routes.account
    import main.routes.home
    import main.routes.registration_codes
